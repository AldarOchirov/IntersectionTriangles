#include "OchirovA_point.h"

using namespace OchirovA;

double CPoint::getX() const
{
	return this->m_x;
}

double CPoint::getY() const
{
	return this->m_y;
}

double CPoint::getZ() const
{
	return this->m_z;
}

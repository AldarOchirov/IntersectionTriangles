#pragma once

namespace OchirovA
{
	enum class CError
	{
		ERROR_DIVISION_BY_ZERO_LINE_PARALLEL_PLANE = -2,
		ERROR_DIVISION_BY_ZERO_LINE_IN_PLANE,
	};
}
